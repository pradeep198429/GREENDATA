package com.pradeep.accountenquiryservice.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.sql.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity(name = "accounts")
public class Account {
    @Id
    @Column(name = "account_number")
    private String accountNumber;
    @Column(name = "account_name")
    private String accountName;
    @Column(name = "user_id")
    private int userId;
    @Column(name = "currency")
    private String currency;
    @Column(name = "balance_date")
    private Date balanceDate;
    @Column(name = "account_type")
    private String accountType;
}
