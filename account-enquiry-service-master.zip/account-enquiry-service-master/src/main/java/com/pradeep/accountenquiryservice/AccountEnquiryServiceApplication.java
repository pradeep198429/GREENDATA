package com.pradeep.accountenquiryservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountEnquiryServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountEnquiryServiceApplication.class, args);
	}

}
