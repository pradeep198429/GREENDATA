package com.pradeep.accountenquiryservice.model;

import com.pradeep.accountenquiryservice.entity.AccountTransaction;
import lombok.*;

import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class TransactionDTO {
    private Date date;
    private String type;
    private Double debitAmount;
    private Double creditAmount;
    private String transactionNarrative;

    public static TransactionDTO from(AccountTransaction accountTransaction) {
        return TransactionDTO.builder()
                .creditAmount(accountTransaction.getCreditAmount())
                .debitAmount(accountTransaction.getDebitAmount())
                .type(accountTransaction.getTransactionType())
                .date(accountTransaction.getTransactionDate())
                .transactionNarrative(accountTransaction.getTransactionNarrative()).build();
    }
}
