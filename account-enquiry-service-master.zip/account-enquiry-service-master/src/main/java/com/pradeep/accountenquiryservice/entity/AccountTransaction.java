package com.pradeep.accountenquiryservice.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import java.sql.Timestamp;

@Data
@Entity(name = "account_transactions")
@NoArgsConstructor
@AllArgsConstructor
@Builder
@IdClass(AccountTransactionId.class)
public class AccountTransaction {
    @Id
    @Column(name = "transaction_id")
    private int transactionId;

    @Id
    @Column(name = "account_number")
    private String accountNumber;
    @Column(name = "debit_amount")
    private Double debitAmount;
    @Column(name = "credit_amount")
    private Double creditAmount;
    @Column(name = "transaction_type")
    private String transactionType;
    @Column(name = "transaction_date")
    private Timestamp transactionDate;
    @Column(name = "transaction_narrative")
    private String transactionNarrative;
}
