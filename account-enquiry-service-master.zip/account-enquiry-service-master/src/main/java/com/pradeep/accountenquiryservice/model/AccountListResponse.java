package com.pradeep.accountenquiryservice.model;

import com.pradeep.accountenquiryservice.entity.Account;
import lombok.*;

import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class AccountListResponse {
    private String accountNumber;
    private String accountName;
    private String accountType;
    private Date balanceDate;
    private String currency;
    private double openingBalance;

    public static AccountListResponse from(Account account, double balance) {
        return AccountListResponse.builder()
                .accountNumber(account.getAccountNumber())
                .accountName(account.getAccountName())
                .accountType(account.getAccountType())
                .balanceDate(account.getBalanceDate())
                .currency(account.getCurrency())
                .openingBalance(balance)
                .build();
    }
}
