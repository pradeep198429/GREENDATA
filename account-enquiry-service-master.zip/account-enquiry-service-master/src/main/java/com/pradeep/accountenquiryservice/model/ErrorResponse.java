package com.pradeep.accountenquiryservice.model;

import lombok.*;

@Data
@Builder
public class ErrorResponse {
    private String error;
}
