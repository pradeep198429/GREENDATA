package com.pradeep.accountenquiryservice.model;

import lombok.*;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class AccountTransactionResponse {
    private String accountNumber;
    private String accountName;
    private String currency;
    private List<TransactionDTO> transactions;
}
